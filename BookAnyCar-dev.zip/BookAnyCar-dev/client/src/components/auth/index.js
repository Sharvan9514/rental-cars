import AuthPage from "./authpage";
const authComponent = () => {
  

  return <AuthPage />;
};
export default authComponent;

const Cars = () => {
  return (
    <div>
      <div class="home-intro">
        <h2>Select the car you want</h2>
      </div>
      <div class="car-list-container"></div>
    </div>
  );
};
export default Cars;

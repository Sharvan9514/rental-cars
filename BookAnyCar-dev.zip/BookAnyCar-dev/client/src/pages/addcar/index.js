import LoginSignupPage from "../../components/auth";
const AddCar = () => {
  return (
    <div className="container">
      <div className="home-intro">
        <h2>Give your car on rent and earn money</h2>
      </div>
      {/* <AddCarForm /> */}
      <LoginSignupPage />
    </div>
  );
};
export default AddCar;

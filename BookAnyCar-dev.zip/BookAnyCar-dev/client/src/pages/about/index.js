
import "./about.css";
const AboutPage = () => {
  return (
    <div className="container">
      <h1 className="about-heading">About Book Any Car</h1>
    </div>
  );
};
export default AboutPage;
